"""
33) Write a Python program to check a list is empty or not.
Ans : if statement directly with the list. If the list is empty, it will return to False"""

def is_list_empty(my_list):
    if not my_list:
        return True 
    else:
        return False  

#true
my_list = []
print(is_list_empty(my_list)) 

#false
my_list = [1, 2, 3]
print(is_list_empty(my_list)) 