"""
13) Write a Python program that will return true if the two given 
integer values are equal or their sum or difference is 5. 
Ans :"""
def check_conditions(a, b):
   
    if a == b or a + b == 5 or abs(a - b) == 5:
        return True
    else:
        return False

try:
    a = int(input("Enter the first integer: "))
    b = int(input("Enter the second integer: "))

    result = check_conditions(a, b)
    print("Result:", result)

except ValueError:
    print("Please enter valid integers.")