"""
82) Write a Python program to copy the contents of a file to another file. 
Ans :"""

source_file = 'source.txt'
destination_file = 'destination.txt'


try:
    with open(source_file, 'r') as src_file:
        with open(destination_file, 'w') as dest_file:
            content = src_file.read()
            dest_file.write(content)
    
    print(f"Contents from '{source_file}' have been copied to '{destination_file}'.")

except FileNotFoundError:
    print(f"Error: The file '{source_file}' was not found.")
except IOError as e:
    print(f"Error: An IO error occurred: {e}")
