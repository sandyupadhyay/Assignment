"""
46) Write a Python program to convert a list of tuples into a dictionary.
Ans :"""

tuple_list = [('a', 1), ('b', 2), ('c', 3)]

result_dict = dict(tuple_list)

print(result_dict)