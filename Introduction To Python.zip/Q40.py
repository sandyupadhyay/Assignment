"""
40) Write a Python program to get unique values from a list
Ans :"""
def get_unique_values(my_list):
   
    unique_values = list(set(my_list))
    return unique_values

my_list = [1, 2, 3, 4, 4, 5, 2, 6, 3]
result = get_unique_values(my_list)
print(f"Unique values: {result}")