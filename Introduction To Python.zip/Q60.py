"""
60) Sample string:
 'w3resource' Expected output: 
• {'3': 1,’s’: 1, 'r': 2, 'u': 1, 'w': 1, 'c': 1, 'e': 2, 'o': 1} 
Ans :"""




st = input("Enter a string: ")

dic = {}

for ch in st:
    if ch in dic:
        dic[ch] += 1
    else:
        
        dic[ch] = 1
print(dic)
