"""
70) How will you randomize the items of a list in place?
Ans :"""
#the random.shuffle() function from the random module.
"""random.shuffle() Function:
This function randomly reorders the elements of a list in place.
It does not return a new list; it modifies the list you pass to it directly

"""

import random

my_list = [1, 2, 3, 4, 5]

random.seed(42)

random.shuffle(my_list)

print(my_list)
