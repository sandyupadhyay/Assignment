"""
36) Write a Python function that takes a list and returns a new list with 
unique elements of the first list.
Ans :"""


def unique_elements(input_list):
    unique_list = list(set(input_list))
    return unique_list

input_list = [1, 2, 3, 4, 4, 5, 2, 6, 3]

result = unique_elements(input_list)

print(result)