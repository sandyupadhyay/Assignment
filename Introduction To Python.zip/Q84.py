"""

84) How many except statements can a try-except block have? Name 
Some built-in exception classes:
Ans :A try-except block in Python can have multiple except statements, allowing you to handle different types of exceptions separately.
     You can include as many except clauses as necessary to handle various exception types that might be raised within the try block.
"""
try:
    x = int(input("Enter a number: "))
    result = 10 / x

except ZeroDivisionError:
    print("Error: Cannot divide by zero.")
except ValueError:
    print("Error: Invalid input, please enter a number.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

#Built-in Exception Classes in Python
"""
1.Exception
2.ZeroDivisionError
3.ValueError
4.TypeError
5.IndexError
6.KeyError
7.FileNotFoundError
8.AttributeError
9.ImportError
10.OSError
11.TimeoutError
12.MemoryError
13.NotImplementedError
14.StopIteration

"""