"""
28) Differentiate between append () and extend () methods? 
Ans : The append() and extend() methods are both used to add elements to a list in Python
    
    1. append()  :      Adds a single element to the end of the list.
                        The element you provide is added as a single item, regardless of its type.
                         If you pass a list to append(), that entire list will be added as one element.

    2. extend()  :      Adds each element from an iterable (list, tuple, string) to the end of the list.
                        Unlike append(), extend() adds individual elements from the iterable to the list, 
                        not the entire iterable as a single element
"""
# Append() :
my_list = [1, 2, 3]
my_list.append(4)  
print(my_list)  

my_list.append([5, 6])  
print(my_list)


# extend() :
my_list = [1, 2, 3]
my_list.extend([4, 5, 6])  
print(my_list) 