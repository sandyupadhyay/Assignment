"""
12) Write a Python program to sum of three given integers. However, if 
two values are equal sum will be zero. 
Ans :"""
def sum_integers(a, b, c):
    if a == b or b == c or a == c:  
        return 0
    else:
        return a + b + c  


try:
    a = int(input("Enter the first integer: "))
    b = int(input("Enter the second integer: "))
    c = int(input("Enter the third integer: "))

   
    result = sum_integers(a, b, c)
    print("The result is:", result)

except ValueError:
    print("Please enter valid integers.")