"""
8) What is the purpose continuing statement in python? 
Ans :   The continue statement skips the remaining code in the current loop iteration and moves to the next iteration.
        It's useful when you want to avoid certain conditions or optimize the flow of your program without breaking the loop entirely (which would be done with break).

"""