"""
39) Write a Python program to find the second smallest number in a list.
Ans :"""
def second_smallest(numbers):

    unique_numbers = list(set(numbers))
    
    if len(unique_numbers) < 2:
        return "There is no second smallest number."
    
    
    unique_numbers.sort()
    return unique_numbers[1]


my_list = [12, 13, 1, 10, 5, 12, 1]
result = second_smallest(my_list)
print(f"The second smallest number is: {result}")