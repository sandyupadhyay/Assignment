"""
19) Write a Python program to count the occurrences of each word in a given sentence
Ans :"""

def count_word_occurrences(sentence):
    words = sentence.lower().split()
    
    word_count = {}
    
    for word in words:
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1
    
    return word_count

sentence = "This is a test. This is only a test."
result = count_word_occurrences(sentence)

print("Word occurrences:")
for word, count in result.items():
    print(f"'{word}': {count}")