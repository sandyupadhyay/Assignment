"""
20) Write a Python program to get a single string from two given strings, 
separated by a space and swap the first two characters of each string.
Ans :"""
def swap_and_combine(str1, str2):
   
    if len(str1) >= 2 and len(str2) >= 2:
       
        str1 = str2[:2] + str1[2:]
        str2 = str1[:2] + str2[2:]
    
   
    combined_str = str1 + " " + str2
    
    return combined_str


str1 = "hello"
str2 = "world"
result = swap_and_combine(str1, str2)

print("Result after swapping and combining:", result)