"""
52) How Do You Check the Presence of a Key in A Dictionary?
Ans :  Using the in Keyword 
       Using the get() Method """


#using in keyyword
my_dict = {'a': 1, 'b': 2, 'c': 3}

# Check if key 'a' exists
if 'a' in my_dict:
    print("Key 'a' is present")
else:
    print("Key 'a' is not present")


#using get method
my_dict = {'a': 1, 'b': 2, 'c': 3}
value = my_dict.get('a')
if value is not None:
    print("Key 'a' is present with value:", value)
else:
    print("Key 'a' is not present")


