"""
87) When is the finally block executed? 
Ans : If no exception is raised: If the code in the try block executes successfully without any exceptions, the finally block will still be executed after
     the try block completes.If an exception is raised and caught: If an exception is raised in the try block and caught by an except block, 
     the finally block will execute after the except block finishes.If an exception is raised but not caught: If an exception is raised in the try block but not 
     caught in an except block, the finally block will still execute before the exception propagates up the call stack.If a return, break, or continue is used: 
     If the try or except block contains a return, break, or continue statement, the finally block will still execute before the method returns, or before
     the loop breaks or continues.

"""
try:
    print("In the try block.")
except ValueError:
    print("In the except block.")
finally:
    print("In the finally block.")
