"""
43) What is tuple? Difference between list and tuple.
Ans : tuple is a collection of ordered elements in Python. Like lists, tuples can store multiple items, but the key difference is that tuples are immutable.
     Once a tuple is created, its values cannot be changed, added, or removed. Tuples are defined using parentheses ().

        Difference : Use a list when you have a collection of items that may need to be modified (i.e., added, removed, or changed).
                    se a tuple when you have a collection of items that should remain constant throughout the program, providing guarantees that the data cannot
                     be accidentally modified.

"""
#syntax of Tuple

my_tuple = (1, 2, 3, 4, 5)


#syntax of List
my_list = [1, 2, 3, 4]

