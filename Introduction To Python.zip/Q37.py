"""
37) Write a Python program to convert a list of characters into a string.
Ans :"""

def list_to_string(char_list):

    result = ''.join(char_list)
    return result

char_list = ['H', 'e', 'l', 'l', 'o']
result = list_to_string(char_list)
print(result)