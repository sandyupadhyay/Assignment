"""
25) What is List? How will you reverse a list?
Ans : list is one of the most commonly used data structures in Python. It is a mutable (i.e., can be changed), ordered collection of elements. 
     list can store elements of different types, such as numbers, strings, or even other lists.
     
     The reversed() method reverses the list in place, meaning it does not return a new list but modifies the original list directly."""
my_list = [1, 2, 3, 4, 5]
reversed_list = list(reversed(my_list))
print(reversed_list)
