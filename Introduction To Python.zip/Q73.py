"""
73) Write a Python program to append text to a file and display the text.
Ans :"""

with open('example.txt', 'a') as file:
    file.write("\nThis is an appended line of text.")

with open('example.txt', 'r') as file:
    content = file.read()
    print(content)