"""
17) What are negative indexes and why are they used? 
Ans : Negative indexes work in the opposite direction. They start from the last element of the sequence and move backwards.
      -1 represents the last element, -2 the second-to-last, and so on.
      They simplify code and make it easier to work with the end of sequences, especially when the sequence length is unknown or dynamic.
      Negative indexes are especially useful for tasks like extracting the last few elements of a list or string without needing to know or calculate the sequence's length.
"""