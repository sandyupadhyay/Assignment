"""
7) How memory is managed in Python? 
Ans :Memory management in Python is handled automatically by the Python interpreter, and it involves several components that
     ensure efficient allocation and deallocation of memory.

    Automatic Memory Management: Python automatically manages memory through reference counting and garbage collection.
    Reference Counting          : Every object has a reference count, and when the count reaches zero, the object is deallocated.
    Garbage Collection          : Periodically runs to clean up cyclic references and unreachable objects.
    Memory Allocators           : Python uses specialized allocators to handle memory efficiently for small and large objects.
    Memory Leaks                : Circular references and global variables can prevent the garbage collector from cleaning up memory, leading to leaks.

"""

