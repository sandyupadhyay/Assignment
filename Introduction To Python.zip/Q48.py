"""
48) Write a Python script to sort (ascending and descending) a 
dictionary by value.
Ans :"""

# Sample dictionary
my_dict = {
    "apple": 10,
    "banana": 5,
    "cherry": 20,
    "date": 15
}


ascending_sorted = dict(sorted(my_dict.items(), key=lambda item: item[1]))
descending_sorted = dict(sorted(my_dict.items(), key=lambda item: item[1], reverse=True))

print("Dictionary sorted by value in ascending order:")
print(ascending_sorted)

print("\nDictionary sorted by value in descending order:")
print(descending_sorted)
