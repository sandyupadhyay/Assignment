"""
90) Write python program that user to enter only odd numbers, else 
will raise an exception.
Ans :"""
class OddNumberError(Exception):
    """Custom exception for handling non-odd numbers."""
    pass

def get_odd_number():
    while True:
        try:
            user_input = input("Enter an odd number: ")
        
            number = int(user_input)
            if number % 2 == 0:
                raise OddNumberError(f"{number} is not an odd number!")
            
           
            print(f"Thank you! {number} is an odd number.")
            return number
        
        except ValueError:
            print("Invalid input! Please enter a valid number.")
        except OddNumberError as e:
            print(e)
get_odd_number()
