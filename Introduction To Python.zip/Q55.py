"""
55) Write a Python script to merge two Python dictionaries
Ans :1.Using the update() method
     2.Using the ** unpacking operator """

#1.Using the update() method

dict1 = {'a': 1, 'b': 2}
dict2 = {'b': 3, 'c': 4}

dict1.update(dict2)
print(dict1)

#2.Using the ** unpacking operator

dict1 = {'a': 1, 'b': 2}
dict2 = {'b': 3, 'c': 4}

merged_dict = {**dict1, **dict2}
print(merged_dict)