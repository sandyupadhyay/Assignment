"""
27) Suppose list1 is [2, 33, 222, 14, and 25], what is list1 [-1]?  
Ans : list1[-1] refers to the last element of the list.
      
"""
list1 = [2, 33, 222, 14, 25]
print(list1[-1])