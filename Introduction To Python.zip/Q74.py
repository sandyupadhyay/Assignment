"""
74) Write a Python program to read first n lines of a file.
Ans :"""
def read_first_n_lines(filename, n):

    with open(filename, 'r') as file:

        for i in range(n):
            line = file.readline()
            if line == '': 
                print("End of file reached. Only", i, "lines were read.")
                break
            print(line.strip())  


filename = 'example.txt'
n = 5  
read_first_n_lines(filename, n)