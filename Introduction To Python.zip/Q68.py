"""
68) How can you get a random number in python? 
Ans :"""

import random

# 1. Random float between 0 and 1
print("Random float:", random.random())

# 2. Random integer between 1 and 10 (inclusive)
print("Random integer:", random.randint(1, 10))

# 3. Random integer between 1 and 9 (exclusive of 10)
print("Random integer (exclusive 10):", random.randrange(1, 10))

# 4. Random float between 1.5 and 5.5
print("Random float (1.5 to 5.5):", random.uniform(1.5, 5.5))

# 5. Random choice from a list
my_list = [10, 20, 30, 40, 50]
print("Random choice from list:", random.choice(my_list))

# 6. Random number with normal distribution (mean=0, std dev=1)
print("Random Gaussian number:", random.gauss(0, 1))
