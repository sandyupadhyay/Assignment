"""
50) Write a Python script to check if a given key already exists in a 
dictionary.

Ans :"""
my_dict = {
    "apple": 10,
    "banana": 5,
    "cherry": 20,
    "date": 15
}

def check_key_exists(dictionary, key):
    if key in dictionary:
        print(f"Key '{key}' exists in the dictionary.")
    else:
        print(f"Key '{key}' does not exist in the dictionary.")


key_to_check = "banana"
check_key_exists(my_dict, key_to_check)

key_to_check = "orange"
check_key_exists(my_dict, key_to_check)