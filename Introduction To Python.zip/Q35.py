"""
35) Write a Python program to generate and print a list of first and last 5 
elements where the values are square of numbers between 1 and 30. 
Ans :"""

squares = [i**2 for i in range(1, 31)]

first_5 = squares[:5]
last_5 = squares[-5:]

result = first_5 + last_5
print(result)